<?php
function conectar(){
	$conecta=mysqli_connect("localhost", "red_itq", "10141205", "red_itq");
	if(!$conecta) {echo "Error".mysqli_connect_error($conecta). "no.".mysqli_connect_errno($conecta);}
	else {
		return $conecta;
	}
	
}

function mostrar_mensajes_inicio($con){
	$query="select * from mensajes where id_padre='0' order by id_mensaje desc limit 5";
	
	if (!$resultado=mysqli_query($con,$query)) {echo "Error". mysqli_error($con);}
	else{
	
	while($muestra=mysqli_fetch_array($resultado)){
		echo "<span class='marker'>Tema:".$muestra['asunto']."<br/></span>";
		echo "".$muestra['descripcion']."<a href='php/contesta_mensaje.php?id_padre=".$muestra['id_mensaje']."'> Contestar</a><br>";
		//mensajes_respuesta($muestra['id_mensaje'],$con);
	}

	}}

function mostrar_mensajes($con,$id_usuario){
	
	$query="select * from mensajes where id_usuario='".$id_usuario."' AND id_mensaje=id_padre order by id_mensaje desc";
	
	if (!$resultado=mysqli_query($con,$query)) {echo "Error". mysqli_error($con);}
	else{
	
	while($muestra=mysqli_fetch_array($resultado)){
		echo "<span class='marker'>Tema:".$muestra['asunto']."<br/></span>";
		echo "".utf8_encode($muestra['descripcion'])."<a href='contesta_mensaje.php?id_padre=".$muestra['id_padre']."'> Contestar</a><br><a href='ver_respuesta_mensaje.php?id=".$muestra['id_mensaje']."'> Ver respuestas</a><br>";
		$_SESSION['id_mensaje']=$muestra['id_mensaje'];
		$_SESSION['id_padrex']=$muestra['id_mensaje']+1;
		
		//mensajes_respuesta($muestra['id_mensaje'],$con);
	}

	}
	
	
}
function mensajes_respuesta($padre,$link){
	
	echo $query="select * from mensajes where id_padre='".$padre."'";
	
	if (!$resultado=mysqli_query($link,$query)) {echo "Error". mysqli_error($link);}
	else{
	
	while($muestra=mysqli_fetch_array($resultado)){
		echo "".utf8_encode($muestra['descripcion'])."</br></span>";
	}

	}
	
}



function obtener_usuarios($link){
	
	echo $query="select * from usuarios";
	
	if (!$resultado=mysqli_query($link,$query)) {echo "Error". mysqli_error($link);}
	else{
	
	echo "<br>Enviar a: <select name='select' id='select'>"; 
	while($muestra=mysqli_fetch_array($resultado)){
echo "<option value='$muestra[id_usuario]' selected>", $muestra['nombre_largo'], "</option>"; 
	}

	}
	
}


function ver_tipo_usuario($con){
	$query="select * from tipo_usuario";
	if (!$resultado=mysqli_query($con,$query)) {echo "Error". mysqli_error($con);}
	else{
	
	while($muestra=mysqli_fetch_array($resultado)){
		echo "".utf8_encode($muestra['descripcion']);
		if($_SESSION['tipo_usuario']==1){

		echo "<a href='eliminar_tipo_usuario.php?id_eliminar=".$muestra['id_tipo_usuario']."'>eliminar</a></br></span>";
	}
	}

	}
 
}
function validar(){
	if (!isset($_SESSION['login'])) {
	header("location:sinacceso.php");	
	}else{
		return true;
	}
}
function salir(){
	session_destroy();
}


function obtener_ultimo_mensaje($con){
	$query="select id_mensaje from mensajes order by id_mensaje desc limit 1";
	if (!$resultado=mysqli_query($con,$query)) {echo "Error". mysqli_error($con);}
	else{
	
	while($muestra=mysqli_fetch_array($resultado)){
		$_SESSION['ultimo_registro']=$muestra['id_mensaje']+1;
		echo $_SESSION['ultimo_registro'];
	}

	}
 
}







































